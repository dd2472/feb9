package com.hcl.demo.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.demo.model.Employee;
import com.hcl.demo.repository.EmployeeRepository;
import com.hcl.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	/**
	 * Constructor Injection
	 */

	/*
	 * private final EmployeeRepository employeeRepository;
	 * 
	 * public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
	 * this.employeeRepository = employeeRepository; }
	 */

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public String addEmployee(Employee employee) {

		Optional<Employee> alreadyExistEmp = employeeRepository.findByEmployeeCode(employee.getEmployeeCode());
		if (alreadyExistEmp.isPresent()) {
			return "Employee Already Existed";
		} else {
			employeeRepository.save(employee);
			return "Employee Saved Successfully";

		}
	}

}
