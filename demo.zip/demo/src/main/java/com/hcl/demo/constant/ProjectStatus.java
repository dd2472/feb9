package com.hcl.demo.constant;

public enum ProjectStatus{
	UNDER_TRAINING,
	DEPLOYED
}