package com.hcl.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.demo.model.Employee;
import com.hcl.demo.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/api/employee/add")
	public String addEmployee(@RequestBody @Valid Employee employee) {
		
		
		return employeeService.addEmployee(employee);
	
	}
}
