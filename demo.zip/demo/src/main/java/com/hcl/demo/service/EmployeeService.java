package com.hcl.demo.service;

import com.hcl.demo.model.Employee;

public interface EmployeeService {
	
	String addEmployee(Employee employee);
}
